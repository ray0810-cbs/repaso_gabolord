package com.example.repasitogabo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RepasitoGaboApplication {

    public static void main(String[] args) {
        SpringApplication.run(RepasitoGaboApplication.class, args);
    }

}
