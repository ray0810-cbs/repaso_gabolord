package com.example.repasitogabo.dto;

import lombok.Data;

@Data
public class SalonCreateDTO {
    private String codigo;
    private String grado;

}
