package com.example.repasitogabo.clases;

public enum Rol {
    ROLE_ESTUDIANTE,
    ROLE_TUTOR,
    ROLE_ADMIN
}
